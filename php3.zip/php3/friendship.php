<?php

require_once 'vendor/autoload.php';
require_once 'constants.php';
require_once 'repetitivefunctions.php';
require_once 'middleware.php';

use Predis\Client as PredisClient;

class FriendshipClass {
    private PredisClient $redisClient;
    private RepetitiveFunctions $repetitiveFunctions;
    private AuthMiddleware $authMiddleware;

    public function __construct(PredisClient $redisClient, RepetitiveFunctions $repetitiveFunctions, AuthMiddleware $authMiddleware) {
        $this->redisClient = $redisClient;
        $this->repetitiveFunctions = $repetitiveFunctions;
        $this->authMiddleware = $authMiddleware;
    }

    // Kullanıcı arama işlemi
    public function searchUser(string $username) {
        try {
            // Kendi username'ini aratmayı engelle
            $currentUserId = $this->authMiddleware->getCurrentUserId();
            $currentUserUsername = $this->redisClient->get(ConstantsClass::USER_PREFIX . $currentUserId);
            if ($currentUserUsername && $username === json_decode($currentUserUsername, true)['username']) {
                return $this->repetitiveFunctions->handleLogError("You cannot search for your own username.");
            }

            // Aranan username sistemde var mı kontrol et
            $userId = $this->redisClient->get(ConstantsClass::USERNAME_PREFIX . $username);
            if (!$userId) {
                return $this->repetitiveFunctions->handleLogError("User not found.");
            }

            return $this->repetitiveFunctions->responseSuccess(['id' => (int)$userId]);
        } catch (Exception $e) {
            return $this->repetitiveFunctions->responseError($e->getMessage());
        }
    }

    public function sendFriendRequest(int $targetUserId) {
        try {
            // Geçerli kullanıcıyı al
            $currentUserId = $this->authMiddleware->getCurrentUserId();
    
            // Kullanıcı ID'lerini doğrula
            if ($currentUserId === $targetUserId) {
                return $this->repetitiveFunctions->handleLogError('Cannot send friend request to yourself.');
            }
    
            // Aynı kullanıcıya iki kez talep gönderme kontrolü
            $existingRequest = $this->redisClient->hGet('friend_requests:' . $targetUserId, $currentUserId);
            if ($existingRequest) {
                return $this->repetitiveFunctions->handleLogError('Friend request already sent');
            }
    
            // Arkadaşlık talebi gönder
            $result = $this->redisClient->hSet('friend_requests:' . $targetUserId, $currentUserId, json_encode([
                'status' => 'pending',
                'date' => time()
            ]));
    
            if ($result) {
                return $this->repetitiveFunctions->responseSuccess([
                    'userId' => $currentUserId,
                    'targetUserId' => $targetUserId
                ]);
            } else {
                return $this->repetitiveFunctions->handleLogError('Failed to send friend request');
            }
        } catch (Exception $e) {
            return $this->repetitiveFunctions->responseError($e->getMessage());
        }
    }

    public function listFriendRequests(int $page = 1, int $count = 10) {
        try {
            $currentUserId = $this->authMiddleware->getCurrentUserId();
            
            // Redis hash'inden arkadaşlık isteklerini al
            $requests = $this->redisClient->hGetAll('friend_requests:' . $currentUserId);
            
            if (!$requests) {
                return $this->repetitiveFunctions->responseSuccess([
                    'requests' => []
                ]);
            }
            
            // İstekleri sayfalama
            $requestsArray = array_values($requests);
            $start = ($page - 1) * $count;
            $requestsArray = array_slice($requestsArray, $start, $count);
            
            // Kullanıcı adlarını al
            $userIds = array_keys($requests);
            $usernames = [];
            foreach ($userIds as $userId) {
                $username = $this->redisClient->get(ConstantsClass::USER_PREFIX . $userId);
                $usernames[$userId] = json_decode($username, true)['username'] ?? 'Unknown';
            }
            
            // İstek bilgilerini hazırlama
            $result = [];
            foreach ($requestsArray as $userIdJson) {
                $requestData = json_decode($userIdJson, true);
                $result[] = [
                    'userid' => $userId,
                    'username' => $usernames[$userId],
                    'date' => date('Y-m-d H:i:s', $requestData['date'])
                ];
            }
            
            return $this->repetitiveFunctions->responseSuccess([
                'requests' => $result
            ]);
        } catch (Exception $e) {
            return $this->repetitiveFunctions->responseError($e->getMessage());
        }
    }

    public function acceptRejectFriendRequest(int $targetUserId, string $status) {
        try {
            // Mevcut kullanıcıyı al
            $currentUserId = $this->authMiddleware->getCurrentUserId();
    
            // Geçerli bir durum değeri mi kontrol et
            if (!in_array($status, ['accept', 'reject'])) {
                return $this->repetitiveFunctions->handleLogError('Invalid status');
            }
    
            // Arkadaşlık isteği mevcut mu kontrol et
            $request = $this->redisClient->hGet('friend_requests:' . $currentUserId, $targetUserId);
            if (!$request) {
                return $this->repetitiveFunctions->handleLogError('Friend request not found');
            }
    
            // İsteği kabul et
            if ($status === 'accept') {
                // İki kullanıcıyı arkadaş olarak işaretle
                $this->redisClient->sAdd('friends:' . $currentUserId, [$targetUserId]);
                $this->redisClient->sAdd('friends:' . $targetUserId, [$currentUserId]);
    
                // İsteği sil
                $this->redisClient->hDel('friend_requests:' . $currentUserId, [$targetUserId]);
    
                return $this->repetitiveFunctions->responseSuccess([
                    'userId' => $currentUserId,
                    'targetUserId' => $targetUserId,
                    'status' => 'accepted'
                ]);
            }
    
            // İsteği reddet
            if ($status === 'reject') {
                // İsteği sil
                $this->redisClient->hDel('friend_requests:' . $currentUserId, [$targetUserId]);
    
                return $this->repetitiveFunctions->responseSuccess([
                    'userId' => $currentUserId,
                    'targetUserId' => $targetUserId,
                    'status' => 'rejected'
                ]);
            }
    
        } catch (Exception $e) {
            return $this->repetitiveFunctions->responseError($e->getMessage());
        }
    }

    public function listFriends(int $page = 1, int $count = 10) {
        try {
            $currentUserId = $this->authMiddleware->getCurrentUserId();
    
            // Kullanıcının arkadaşlarını al
            $friends = $this->redisClient->sMembers('friends:' . $currentUserId);
            if (!$friends) {
                return $this->repetitiveFunctions->handleLogError('No friends found');
            }
    
            // Sayfalama için gerekli sınırları hesapla
            $start = ($page - 1) * $count;
            $end = $start + $count - 1;
    
            // Arkadaşları kesip al
            $friendsSubset = array_slice($friends, $start, $count);
    
            // Arkadaşların kullanıcı adlarını al
            $friendDetails = [];
            foreach ($friendsSubset as $friendId) {
                $friendUsername = $this->redisClient->get(ConstantsClass::USER_PREFIX . $friendId);
                if ($friendUsername) {
                    $friendDetails[] = [
                        'userid' => (int)$friendId,
                        'username' => json_decode($friendUsername, true)['username']
                    ];
                }
            }
    
            return $this->repetitiveFunctions->responseSuccess([
                'friends' => $friendDetails
            ]);
        } catch (Exception $e) {
            return $this->repetitiveFunctions->responseError($e->getMessage());
        }
    }
    
    
}

